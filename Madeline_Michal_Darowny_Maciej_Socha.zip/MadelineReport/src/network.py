class Madeline:
    def __init__(self):
        self.copying_layer = []
